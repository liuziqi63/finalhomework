package org.example.javaee.class01.dao;

import org.example.javaee.class01.model.Homework;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface HomeworkDao {
    public List<Homework> selectAll() throws Exception;

    public boolean insert(Homework homework) throws Exception;
}
