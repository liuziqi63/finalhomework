package org.example.javaee.class01.dao;

import org.example.javaee.class01.model.Student;
import org.example.javaee.class01.model.StudentHomework;

import java.util.List;

public interface StudentHomeworkDao {
    public List<StudentHomework> selectByHWId(Long homeworkId) throws Exception;

    public boolean insert(StudentHomework studentHomework) throws Exception;
}
